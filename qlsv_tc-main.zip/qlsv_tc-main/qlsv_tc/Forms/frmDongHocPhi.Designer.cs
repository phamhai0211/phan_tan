﻿
namespace qlsv_tc.Forms
{
    partial class frmDongHocPhi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions2 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDongHocPhi));
            this.pnThongTinSV = new DevExpress.XtraEditors.PanelControl();
            this.cmbMASV = new DevExpress.XtraEditors.LookUpEdit();
            this.bdsSV = new System.Windows.Forms.BindingSource(this.components);
            this.dS3 = new qlsv_tc.DS3();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.panel4 = new System.Windows.Forms.Panel();
            this.CTHPGridControl = new DevExpress.XtraGrid.GridControl();
            this.bdsCTHP = new System.Windows.Forms.BindingSource(this.components);
            this.bdsHP = new System.Windows.Forms.BindingSource(this.components);
            this.viewCTHP = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colMASV1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNIENKHOA1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHOCKY1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNGAYDONG = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSOTIENDONG = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rtxtSoTienDong = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.HPGridControl = new DevExpress.XtraGrid.GridControl();
            this.viewHP = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colMASV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNIENKHOA = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rTxtNienKhoa = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colHOCKY = new DevExpress.XtraGrid.Columns.GridColumn();
            this.spinEditHocKy = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.colHOCPHI = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rTxtHocPhi = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colSOTIENDADONG = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSOTIENCANDONG = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDongHocPhi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnDongHocPhi = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tableAdapterManager = new qlsv_tc.DS3TableAdapters.TableAdapterManager();
            this.tableAdapterSV = new qlsv_tc.DS3TableAdapters.SINHVIENTableAdapter();
            this.pnBody = new System.Windows.Forms.Panel();
            this.tableAdapterHP = new qlsv_tc.DS3TableAdapters.HOCPHITableAdapter();
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.btnThem = new DevExpress.XtraBars.BarButtonItem();
            this.btnHieuChinh = new DevExpress.XtraBars.BarButtonItem();
            this.btnGhi = new DevExpress.XtraBars.BarButtonItem();
            this.btnUndo = new DevExpress.XtraBars.BarButtonItem();
            this.btnHuy = new DevExpress.XtraBars.BarButtonItem();
            this.btnReload = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.barBtnThem = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnGhi = new DevExpress.XtraBars.BarButtonItem();
            this.btnXoa = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnHuy = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnReload = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnThoat = new DevExpress.XtraBars.BarButtonItem();
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControl1 = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem11 = new DevExpress.XtraBars.BarButtonItem();
            this.err = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableAdapterCTHP = new qlsv_tc.DS3TableAdapters.CT_DONGHOCPHITableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pnThongTinSV)).BeginInit();
            this.pnThongTinSV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbMASV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsSV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dS3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CTHPGridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCTHP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsHP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCTHP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rtxtSoTienDong)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HPGridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewHP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rTxtNienKhoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditHocKy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rTxtHocPhi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDongHocPhi)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.pnBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.err)).BeginInit();
            this.SuspendLayout();
            // 
            // pnThongTinSV
            // 
            this.pnThongTinSV.Controls.Add(this.cmbMASV);
            this.pnThongTinSV.Controls.Add(this.txtHoTen);
            this.pnThongTinSV.Controls.Add(this.txtMaLop);
            this.pnThongTinSV.Controls.Add(this.label3);
            this.pnThongTinSV.Controls.Add(this.label2);
            this.pnThongTinSV.Controls.Add(this.label1);
            this.pnThongTinSV.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnThongTinSV.Location = new System.Drawing.Point(0, 34);
            this.pnThongTinSV.Name = "pnThongTinSV";
            this.pnThongTinSV.Size = new System.Drawing.Size(1614, 55);
            this.pnThongTinSV.TabIndex = 4;
            // 
            // cmbMASV
            // 
            this.cmbMASV.Location = new System.Drawing.Point(202, 10);
            this.cmbMASV.Name = "cmbMASV";
            this.cmbMASV.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMASV.Properties.Appearance.Options.UseFont = true;
            this.cmbMASV.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbMASV.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MASV", "MASV", 80, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center, DevExpress.Data.ColumnSortOrder.Ascending, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("HO", "HO", 38, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Near, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TEN", "TEN", 48, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Near, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("NGAYSINH", "NGAYSINH", 111, DevExpress.Utils.FormatType.DateTime, "M/d/yyyy", false, DevExpress.Utils.HorzAlignment.Near, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MALOP", "MALOP", 77, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Near, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("DANGHIHOC", "DANGHIHOC", 127, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Near, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default)});
            this.cmbMASV.Properties.DataSource = this.bdsSV;
            this.cmbMASV.Properties.DisplayMember = "MASV";
            this.cmbMASV.Properties.NullText = "Tìm MÃ SV";
            this.cmbMASV.Properties.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoSearch;
            this.cmbMASV.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cmbMASV.Properties.ValueMember = "MASV";
            this.cmbMASV.Size = new System.Drawing.Size(286, 30);
            this.cmbMASV.TabIndex = 7;
            this.cmbMASV.EditValueChanged += new System.EventHandler(this.cmbMASV_EditValueChanged);
            // 
            // bdsSV
            // 
            this.bdsSV.DataMember = "SINHVIEN";
            this.bdsSV.DataSource = this.dS3;
            // 
            // dS3
            // 
            this.dS3.DataSetName = "DS3";
            this.dS3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtHoTen
            // 
            this.txtHoTen.Enabled = false;
            this.txtHoTen.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTen.Location = new System.Drawing.Point(616, 7);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(287, 30);
            this.txtHoTen.TabIndex = 5;
            // 
            // txtMaLop
            // 
            this.txtMaLop.Enabled = false;
            this.txtMaLop.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaLop.Location = new System.Drawing.Point(1082, 7);
            this.txtMaLop.Name = "txtMaLop";
            this.txtMaLop.Size = new System.Drawing.Size(239, 30);
            this.txtMaLop.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1003, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mã Lớp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(541, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ Tên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã SV";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.panel4);
            this.panelControl1.Controls.Add(this.panel3);
            this.panelControl1.Controls.Add(this.panel2);
            this.panelControl1.Controls.Add(this.panel1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1614, 950);
            this.panelControl1.TabIndex = 19;
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.CTHPGridControl);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(2, 321);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1610, 627);
            this.panel4.TabIndex = 6;
            // 
            // CTHPGridControl
            // 
            this.CTHPGridControl.DataSource = this.bdsCTHP;
            this.CTHPGridControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CTHPGridControl.Location = new System.Drawing.Point(0, 0);
            this.CTHPGridControl.MainView = this.viewCTHP;
            this.CTHPGridControl.Name = "CTHPGridControl";
            this.CTHPGridControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rtxtSoTienDong});
            this.CTHPGridControl.Size = new System.Drawing.Size(1610, 627);
            this.CTHPGridControl.TabIndex = 0;
            this.CTHPGridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.viewCTHP});
            // 
            // bdsCTHP
            // 
            this.bdsCTHP.DataMember = "FK_CT_DONGHOCPHI_HOCPHI";
            this.bdsCTHP.DataSource = this.bdsHP;
            // 
            // bdsHP
            // 
            this.bdsHP.DataMember = "HOCPHI";
            this.bdsHP.DataSource = this.dS3;
            // 
            // viewCTHP
            // 
            this.viewCTHP.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colMASV1,
            this.colNIENKHOA1,
            this.colHOCKY1,
            this.colNGAYDONG,
            this.colSOTIENDONG});
            this.viewCTHP.GridControl = this.CTHPGridControl;
            this.viewCTHP.Name = "viewCTHP";
            this.viewCTHP.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.viewCTHP_CellValueChanged);
            // 
            // colMASV1
            // 
            this.colMASV1.AppearanceCell.Options.UseTextOptions = true;
            this.colMASV1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMASV1.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colMASV1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colMASV1.AppearanceHeader.Options.UseBackColor = true;
            this.colMASV1.AppearanceHeader.Options.UseFont = true;
            this.colMASV1.AppearanceHeader.Options.UseTextOptions = true;
            this.colMASV1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMASV1.FieldName = "MASV";
            this.colMASV1.MinWidth = 30;
            this.colMASV1.Name = "colMASV1";
            this.colMASV1.OptionsColumn.AllowEdit = false;
            this.colMASV1.OptionsColumn.AllowFocus = false;
            this.colMASV1.Width = 112;
            // 
            // colNIENKHOA1
            // 
            this.colNIENKHOA1.AppearanceCell.Options.UseTextOptions = true;
            this.colNIENKHOA1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNIENKHOA1.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colNIENKHOA1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colNIENKHOA1.AppearanceHeader.Options.UseBackColor = true;
            this.colNIENKHOA1.AppearanceHeader.Options.UseFont = true;
            this.colNIENKHOA1.AppearanceHeader.Options.UseTextOptions = true;
            this.colNIENKHOA1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNIENKHOA1.FieldName = "NIENKHOA";
            this.colNIENKHOA1.MinWidth = 30;
            this.colNIENKHOA1.Name = "colNIENKHOA1";
            this.colNIENKHOA1.OptionsColumn.AllowEdit = false;
            this.colNIENKHOA1.OptionsColumn.AllowFocus = false;
            this.colNIENKHOA1.Width = 112;
            // 
            // colHOCKY1
            // 
            this.colHOCKY1.AppearanceCell.Options.UseTextOptions = true;
            this.colHOCKY1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHOCKY1.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colHOCKY1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colHOCKY1.AppearanceHeader.Options.UseBackColor = true;
            this.colHOCKY1.AppearanceHeader.Options.UseFont = true;
            this.colHOCKY1.AppearanceHeader.Options.UseTextOptions = true;
            this.colHOCKY1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHOCKY1.FieldName = "HOCKY";
            this.colHOCKY1.MinWidth = 30;
            this.colHOCKY1.Name = "colHOCKY1";
            this.colHOCKY1.OptionsColumn.AllowEdit = false;
            this.colHOCKY1.OptionsColumn.AllowFocus = false;
            this.colHOCKY1.Width = 112;
            // 
            // colNGAYDONG
            // 
            this.colNGAYDONG.AppearanceCell.Options.UseTextOptions = true;
            this.colNGAYDONG.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNGAYDONG.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colNGAYDONG.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colNGAYDONG.AppearanceHeader.Options.UseBackColor = true;
            this.colNGAYDONG.AppearanceHeader.Options.UseFont = true;
            this.colNGAYDONG.AppearanceHeader.Options.UseTextOptions = true;
            this.colNGAYDONG.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNGAYDONG.DisplayFormat.FormatString = "G";
            this.colNGAYDONG.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colNGAYDONG.FieldName = "NGAYDONG";
            this.colNGAYDONG.MinWidth = 30;
            this.colNGAYDONG.Name = "colNGAYDONG";
            this.colNGAYDONG.Visible = true;
            this.colNGAYDONG.VisibleIndex = 0;
            this.colNGAYDONG.Width = 112;
            // 
            // colSOTIENDONG
            // 
            this.colSOTIENDONG.AppearanceCell.Options.UseTextOptions = true;
            this.colSOTIENDONG.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSOTIENDONG.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colSOTIENDONG.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colSOTIENDONG.AppearanceHeader.Options.UseBackColor = true;
            this.colSOTIENDONG.AppearanceHeader.Options.UseFont = true;
            this.colSOTIENDONG.AppearanceHeader.Options.UseTextOptions = true;
            this.colSOTIENDONG.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSOTIENDONG.ColumnEdit = this.rtxtSoTienDong;
            this.colSOTIENDONG.DisplayFormat.FormatString = "n0";
            this.colSOTIENDONG.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colSOTIENDONG.FieldName = "SOTIENDONG";
            this.colSOTIENDONG.MinWidth = 30;
            this.colSOTIENDONG.Name = "colSOTIENDONG";
            this.colSOTIENDONG.Visible = true;
            this.colSOTIENDONG.VisibleIndex = 1;
            this.colSOTIENDONG.Width = 112;
            // 
            // rtxtSoTienDong
            // 
            this.rtxtSoTienDong.AutoHeight = false;
            this.rtxtSoTienDong.DisplayFormat.FormatString = "n0";
            this.rtxtSoTienDong.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.rtxtSoTienDong.Name = "rtxtSoTienDong";
            this.rtxtSoTienDong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rTxtHocPhi_KeyPress);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(166)))), ((int)(((byte)(221)))));
            this.panel3.Controls.Add(this.label6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(2, 269);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1610, 52);
            this.panel3.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(27, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(280, 26);
            this.label6.TabIndex = 2;
            this.label6.Text = "Chi Tiết Học Phí Đã Đóng";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.HPGridControl);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(2, 54);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1610, 215);
            this.panel2.TabIndex = 3;
            // 
            // HPGridControl
            // 
            this.HPGridControl.DataSource = this.bdsHP;
            this.HPGridControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HPGridControl.Location = new System.Drawing.Point(0, 0);
            this.HPGridControl.MainView = this.viewHP;
            this.HPGridControl.Name = "HPGridControl";
            this.HPGridControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.spinEditHocKy,
            this.btnDongHocPhi,
            this.rTxtHocPhi,
            this.rTxtNienKhoa});
            this.HPGridControl.Size = new System.Drawing.Size(1610, 215);
            this.HPGridControl.TabIndex = 0;
            this.HPGridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.viewHP});
            // 
            // viewHP
            // 
            this.viewHP.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colMASV,
            this.colNIENKHOA,
            this.colHOCKY,
            this.colHOCPHI,
            this.colSOTIENDADONG,
            this.colSOTIENCANDONG,
            this.colDongHocPhi});
            this.viewHP.GridControl = this.HPGridControl;
            this.viewHP.Name = "viewHP";
            this.viewHP.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.viewHP_InitNewRow);
            this.viewHP.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.viewHP_CellValueChanged);
            // 
            // colMASV
            // 
            this.colMASV.AppearanceCell.Options.UseTextOptions = true;
            this.colMASV.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMASV.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colMASV.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colMASV.AppearanceHeader.Options.UseBackColor = true;
            this.colMASV.AppearanceHeader.Options.UseFont = true;
            this.colMASV.AppearanceHeader.Options.UseTextOptions = true;
            this.colMASV.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMASV.FieldName = "MASV";
            this.colMASV.MinWidth = 30;
            this.colMASV.Name = "colMASV";
            this.colMASV.Width = 112;
            // 
            // colNIENKHOA
            // 
            this.colNIENKHOA.AppearanceCell.Options.UseTextOptions = true;
            this.colNIENKHOA.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNIENKHOA.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colNIENKHOA.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colNIENKHOA.AppearanceHeader.Options.UseBackColor = true;
            this.colNIENKHOA.AppearanceHeader.Options.UseFont = true;
            this.colNIENKHOA.AppearanceHeader.Options.UseTextOptions = true;
            this.colNIENKHOA.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNIENKHOA.ColumnEdit = this.rTxtNienKhoa;
            this.colNIENKHOA.FieldName = "NIENKHOA";
            this.colNIENKHOA.MinWidth = 30;
            this.colNIENKHOA.Name = "colNIENKHOA";
            this.colNIENKHOA.Visible = true;
            this.colNIENKHOA.VisibleIndex = 0;
            this.colNIENKHOA.Width = 112;
            // 
            // rTxtNienKhoa
            // 
            this.rTxtNienKhoa.AutoHeight = false;
            this.rTxtNienKhoa.Name = "rTxtNienKhoa";
            this.rTxtNienKhoa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rTxtNienKhoa_KeyPress);
            // 
            // colHOCKY
            // 
            this.colHOCKY.AppearanceCell.Options.UseTextOptions = true;
            this.colHOCKY.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHOCKY.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colHOCKY.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colHOCKY.AppearanceHeader.Options.UseBackColor = true;
            this.colHOCKY.AppearanceHeader.Options.UseFont = true;
            this.colHOCKY.AppearanceHeader.Options.UseTextOptions = true;
            this.colHOCKY.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHOCKY.ColumnEdit = this.spinEditHocKy;
            this.colHOCKY.FieldName = "HOCKY";
            this.colHOCKY.MinWidth = 30;
            this.colHOCKY.Name = "colHOCKY";
            this.colHOCKY.Visible = true;
            this.colHOCKY.VisibleIndex = 1;
            this.colHOCKY.Width = 112;
            // 
            // spinEditHocKy
            // 
            this.spinEditHocKy.AutoHeight = false;
            this.spinEditHocKy.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.spinEditHocKy.IsFloatValue = false;
            this.spinEditHocKy.Mask.EditMask = "N00";
            this.spinEditHocKy.MaxValue = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.spinEditHocKy.MinValue = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spinEditHocKy.Name = "spinEditHocKy";
            // 
            // colHOCPHI
            // 
            this.colHOCPHI.AppearanceCell.Options.UseTextOptions = true;
            this.colHOCPHI.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHOCPHI.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colHOCPHI.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colHOCPHI.AppearanceHeader.Options.UseBackColor = true;
            this.colHOCPHI.AppearanceHeader.Options.UseFont = true;
            this.colHOCPHI.AppearanceHeader.Options.UseTextOptions = true;
            this.colHOCPHI.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHOCPHI.ColumnEdit = this.rTxtHocPhi;
            this.colHOCPHI.DisplayFormat.FormatString = "n0";
            this.colHOCPHI.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colHOCPHI.FieldName = "HOCPHI";
            this.colHOCPHI.MinWidth = 30;
            this.colHOCPHI.Name = "colHOCPHI";
            this.colHOCPHI.Visible = true;
            this.colHOCPHI.VisibleIndex = 2;
            this.colHOCPHI.Width = 112;
            // 
            // rTxtHocPhi
            // 
            this.rTxtHocPhi.AutoHeight = false;
            this.rTxtHocPhi.DisplayFormat.FormatString = "n0";
            this.rTxtHocPhi.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.rTxtHocPhi.Name = "rTxtHocPhi";
            this.rTxtHocPhi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rTxtHocPhi_KeyPress);
            // 
            // colSOTIENDADONG
            // 
            this.colSOTIENDADONG.AppearanceCell.Options.UseTextOptions = true;
            this.colSOTIENDADONG.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSOTIENDADONG.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colSOTIENDADONG.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colSOTIENDADONG.AppearanceHeader.Options.UseBackColor = true;
            this.colSOTIENDADONG.AppearanceHeader.Options.UseFont = true;
            this.colSOTIENDADONG.AppearanceHeader.Options.UseTextOptions = true;
            this.colSOTIENDADONG.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSOTIENDADONG.DisplayFormat.FormatString = "n0";
            this.colSOTIENDADONG.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colSOTIENDADONG.FieldName = "SOTIENDADONG";
            this.colSOTIENDADONG.MinWidth = 30;
            this.colSOTIENDADONG.Name = "colSOTIENDADONG";
            this.colSOTIENDADONG.OptionsColumn.AllowEdit = false;
            this.colSOTIENDADONG.OptionsColumn.AllowFocus = false;
            this.colSOTIENDADONG.OptionsColumn.ReadOnly = true;
            this.colSOTIENDADONG.Visible = true;
            this.colSOTIENDADONG.VisibleIndex = 3;
            this.colSOTIENDADONG.Width = 112;
            // 
            // colSOTIENCANDONG
            // 
            this.colSOTIENCANDONG.AppearanceCell.Options.UseTextOptions = true;
            this.colSOTIENCANDONG.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSOTIENCANDONG.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colSOTIENCANDONG.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colSOTIENCANDONG.AppearanceHeader.Options.UseBackColor = true;
            this.colSOTIENCANDONG.AppearanceHeader.Options.UseFont = true;
            this.colSOTIENCANDONG.AppearanceHeader.Options.UseTextOptions = true;
            this.colSOTIENCANDONG.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSOTIENCANDONG.DisplayFormat.FormatString = "n0";
            this.colSOTIENCANDONG.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colSOTIENCANDONG.FieldName = "SOTIENCANDONG";
            this.colSOTIENCANDONG.MinWidth = 30;
            this.colSOTIENCANDONG.Name = "colSOTIENCANDONG";
            this.colSOTIENCANDONG.OptionsColumn.AllowEdit = false;
            this.colSOTIENCANDONG.OptionsColumn.AllowFocus = false;
            this.colSOTIENCANDONG.OptionsColumn.ReadOnly = true;
            this.colSOTIENCANDONG.Visible = true;
            this.colSOTIENCANDONG.VisibleIndex = 4;
            this.colSOTIENCANDONG.Width = 112;
            // 
            // colDongHocPhi
            // 
            this.colDongHocPhi.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDongHocPhi.AppearanceCell.Options.UseFont = true;
            this.colDongHocPhi.AppearanceCell.Options.UseTextOptions = true;
            this.colDongHocPhi.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDongHocPhi.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.colDongHocPhi.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDongHocPhi.AppearanceHeader.Options.UseBackColor = true;
            this.colDongHocPhi.AppearanceHeader.Options.UseFont = true;
            this.colDongHocPhi.AppearanceHeader.Options.UseTextOptions = true;
            this.colDongHocPhi.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDongHocPhi.Caption = "Đóng Học Phí";
            this.colDongHocPhi.ColumnEdit = this.btnDongHocPhi;
            this.colDongHocPhi.MinWidth = 30;
            this.colDongHocPhi.Name = "colDongHocPhi";
            this.colDongHocPhi.Visible = true;
            this.colDongHocPhi.VisibleIndex = 5;
            this.colDongHocPhi.Width = 112;
            // 
            // btnDongHocPhi
            // 
            this.btnDongHocPhi.AutoHeight = false;
            this.btnDongHocPhi.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus, "Đóng Học Phí", -1, true, true, false, editorButtonImageOptions2, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject5, serializableAppearanceObject6, serializableAppearanceObject7, serializableAppearanceObject8, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnDongHocPhi.Name = "btnDongHocPhi";
            this.btnDongHocPhi.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnDongHocPhi.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.btnDongHocPhi_ButtonClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(166)))), ((int)(((byte)(221)))));
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1610, 52);
            this.panel1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(27, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(312, 26);
            this.label4.TabIndex = 0;
            this.label4.Text = "Thông Tin Học Phí Sinh Viên";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gridView1
            // 
            this.gridView1.Name = "gridView1";
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.CT_DONGHOCPHITableAdapter = null;
            this.tableAdapterManager.GIANGVIENTableAdapter = null;
            this.tableAdapterManager.HOCPHITableAdapter = null;
            this.tableAdapterManager.KHOATableAdapter = null;
            this.tableAdapterManager.LOPTableAdapter = null;
            this.tableAdapterManager.SINHVIENTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = qlsv_tc.DS3TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tableAdapterSV
            // 
            this.tableAdapterSV.ClearBeforeFill = true;
            // 
            // pnBody
            // 
            this.pnBody.Controls.Add(this.panelControl1);
            this.pnBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnBody.Location = new System.Drawing.Point(0, 89);
            this.pnBody.Name = "pnBody";
            this.pnBody.Size = new System.Drawing.Size(1614, 950);
            this.pnBody.TabIndex = 29;
            // 
            // tableAdapterHP
            // 
            this.tableAdapterHP.ClearBeforeFill = true;
            // 
            // bar1
            // 
            this.bar1.BarName = "Tools";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 0;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.FloatLocation = new System.Drawing.Point(87, 264);
            this.bar1.FloatSize = new System.Drawing.Size(591, 36);
            this.bar1.Offset = 3;
            this.bar1.Text = "Tools";
            // 
            // btnThem
            // 
            this.btnThem.Caption = "Thêm";
            this.btnThem.Id = 1;
            this.btnThem.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnThem.ImageOptions.SvgImage")));
            this.btnThem.Name = "btnThem";
            // 
            // btnHieuChinh
            // 
            this.btnHieuChinh.Caption = "Hiệu Chỉnh";
            this.btnHieuChinh.Id = 3;
            this.btnHieuChinh.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnHieuChinh.ImageOptions.SvgImage")));
            this.btnHieuChinh.Name = "btnHieuChinh";
            // 
            // btnGhi
            // 
            this.btnGhi.Caption = "Ghi";
            this.btnGhi.Id = 4;
            this.btnGhi.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnGhi.ImageOptions.SvgImage")));
            this.btnGhi.Name = "btnGhi";
            // 
            // btnUndo
            // 
            this.btnUndo.Caption = "Phục hồi";
            this.btnUndo.Id = 6;
            this.btnUndo.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnUndo.ImageOptions.SvgImage")));
            this.btnUndo.Name = "btnUndo";
            // 
            // btnHuy
            // 
            this.btnHuy.Caption = "Huỷ";
            this.btnHuy.Id = 9;
            this.btnHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnHuy.ImageOptions.SvgImage")));
            this.btnHuy.Name = "btnHuy";
            // 
            // btnReload
            // 
            this.btnReload.Caption = "Reload";
            this.btnReload.Id = 7;
            this.btnReload.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnReload.ImageOptions.SvgImage")));
            this.btnReload.Name = "btnReload";
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Thoát";
            this.barButtonItem3.Id = 10;
            this.barButtonItem3.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem3.ImageOptions.SvgImage")));
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1614, 34);
            this.barDockControlRight.Manager = null;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 1005);
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2,
            this.bar3});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControl1);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barBtnThem,
            this.barButtonItem10,
            this.barBtnGhi,
            this.barBtnReload,
            this.barButtonItem11,
            this.barBtnHuy,
            this.barBtnThoat,
            this.btnXoa});
            this.barManager1.MaxItemId = 13;
            this.barManager1.StatusBar = this.bar3;
            // 
            // bar2
            // 
            this.bar2.BarName = "Tools";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.FloatLocation = new System.Drawing.Point(804, 320);
            this.bar2.FloatSize = new System.Drawing.Size(591, 36);
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barBtnThem, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barBtnGhi, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnXoa, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barBtnHuy, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barBtnReload, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barBtnThoat, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar2.Offset = 1;
            this.bar2.Text = "Tools";
            // 
            // barBtnThem
            // 
            this.barBtnThem.Caption = "Thêm";
            this.barBtnThem.Id = 1;
            this.barBtnThem.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barBtnThem.ImageOptions.SvgImage")));
            this.barBtnThem.Name = "barBtnThem";
            this.barBtnThem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnThem_ItemClick);
            // 
            // barBtnGhi
            // 
            this.barBtnGhi.Caption = "Ghi";
            this.barBtnGhi.Id = 4;
            this.barBtnGhi.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barBtnGhi.ImageOptions.SvgImage")));
            this.barBtnGhi.Name = "barBtnGhi";
            this.barBtnGhi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnGhi_ItemClick);
            // 
            // btnXoa
            // 
            this.btnXoa.Caption = "Xóa";
            this.btnXoa.Id = 12;
            this.btnXoa.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnXoa.ImageOptions.SvgImage")));
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnXoa_ItemClick);
            // 
            // barBtnHuy
            // 
            this.barBtnHuy.Caption = "Huỷ";
            this.barBtnHuy.Id = 9;
            this.barBtnHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barBtnHuy.ImageOptions.SvgImage")));
            this.barBtnHuy.Name = "barBtnHuy";
            this.barBtnHuy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnHuy_ItemClick);
            // 
            // barBtnReload
            // 
            this.barBtnReload.Caption = "Làm mới";
            this.barBtnReload.Id = 7;
            this.barBtnReload.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barBtnReload.ImageOptions.SvgImage")));
            this.barBtnReload.Name = "barBtnReload";
            this.barBtnReload.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnReload_ItemClick);
            // 
            // barBtnThoat
            // 
            this.barBtnThoat.Caption = "Thoát";
            this.barBtnThoat.Id = 10;
            this.barBtnThoat.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barBtnThoat.ImageOptions.SvgImage")));
            this.barBtnThoat.Name = "barBtnThoat";
            this.barBtnThoat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnThoat_ItemClick);
            // 
            // bar3
            // 
            this.bar3.BarName = "Status bar";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            this.bar3.Text = "Status bar";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1614, 34);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 1039);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1614, 20);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 34);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 1005);
            // 
            // barDockControl1
            // 
            this.barDockControl1.CausesValidation = false;
            this.barDockControl1.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControl1.Location = new System.Drawing.Point(1614, 34);
            this.barDockControl1.Manager = this.barManager1;
            this.barDockControl1.Size = new System.Drawing.Size(0, 1005);
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "barButtonItem2";
            this.barButtonItem10.Id = 2;
            this.barButtonItem10.Name = "barButtonItem10";
            // 
            // barButtonItem11
            // 
            this.barButtonItem11.Caption = "barButtonItem1";
            this.barButtonItem11.Id = 8;
            this.barButtonItem11.Name = "barButtonItem11";
            // 
            // err
            // 
            this.err.ContainerControl = this;
            // 
            // tableAdapterCTHP
            // 
            this.tableAdapterCTHP.ClearBeforeFill = true;
            // 
            // frmDongHocPhi
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1614, 1059);
            this.Controls.Add(this.pnBody);
            this.Controls.Add(this.pnThongTinSV);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControl1);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDongHocPhi";
            this.Text = "Đóng Học Phí";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmDongHocPhi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pnThongTinSV)).EndInit();
            this.pnThongTinSV.ResumeLayout(false);
            this.pnThongTinSV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbMASV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsSV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dS3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CTHPGridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCTHP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsHP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCTHP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rtxtSoTienDong)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HPGridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewHP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rTxtNienKhoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditHocKy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rTxtHocPhi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDongHocPhi)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.pnBody.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.err)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraEditors.PanelControl pnThongTinSV;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DS3 dS3;
        private DS3TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.LookUpEdit cmbMASV;
        private DS3TableAdapters.SINHVIENTableAdapter tableAdapterSV;
        private System.Windows.Forms.Panel pnBody;
        private DevExpress.XtraGrid.GridControl HPGridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView viewHP;
        private System.Windows.Forms.BindingSource bdsSV;
        private DevExpress.XtraGrid.GridControl CTHPGridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView viewCTHP;
        private DevExpress.XtraGrid.Columns.GridColumn colMASV1;
        private DevExpress.XtraGrid.Columns.GridColumn colNIENKHOA1;
        private DevExpress.XtraGrid.Columns.GridColumn colHOCKY1;
        private DevExpress.XtraGrid.Columns.GridColumn colNGAYDONG;
        private DevExpress.XtraGrid.Columns.GridColumn colSOTIENDONG;
        private DevExpress.XtraGrid.Columns.GridColumn colMASV;
        private DevExpress.XtraGrid.Columns.GridColumn colNIENKHOA;
        private DevExpress.XtraGrid.Columns.GridColumn colHOCKY;
        private DevExpress.XtraGrid.Columns.GridColumn colHOCPHI;
        private DevExpress.XtraGrid.Columns.GridColumn colSOTIENDADONG;
        private DevExpress.XtraGrid.Columns.GridColumn colSOTIENCANDONG;
        private System.Windows.Forms.BindingSource bdsHP;
        private DS3TableAdapters.HOCPHITableAdapter tableAdapterHP;
        private DevExpress.XtraBars.Bar bar1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraBars.BarButtonItem btnThem;
        private DevExpress.XtraBars.BarButtonItem btnHieuChinh;
        private DevExpress.XtraBars.BarButtonItem btnGhi;
        private DevExpress.XtraBars.BarButtonItem btnUndo;
        private DevExpress.XtraBars.BarButtonItem btnHuy;
        private DevExpress.XtraBars.BarButtonItem btnReload;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarButtonItem barBtnThem;
        private DevExpress.XtraBars.BarButtonItem barBtnGhi;
        private DevExpress.XtraBars.BarButtonItem barBtnHuy;
        private DevExpress.XtraBars.BarButtonItem barBtnReload;
        private DevExpress.XtraBars.BarButtonItem barBtnThoat;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControl1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.BarButtonItem barButtonItem11;
        private System.Windows.Forms.ErrorProvider err;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit spinEditHocKy;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnDongHocPhi;
        private DevExpress.XtraGrid.Columns.GridColumn colDongHocPhi;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rTxtHocPhi;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rtxtSoTienDong;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rTxtNienKhoa;
        private System.Windows.Forms.BindingSource bdsCTHP;
        private DS3TableAdapters.CT_DONGHOCPHITableAdapter tableAdapterCTHP;
        private DevExpress.XtraBars.BarButtonItem btnXoa;
    }
}